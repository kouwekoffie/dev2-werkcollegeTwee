"use strict";
import { photoStore, currencies, photos } from './index';


const checkSortBy = () => {
  photoStore.photos.forEach((photo, index) => {
    if (photoStore.photos[index + 1]) {
      const nextPhoto = photoStore.photos[index + 1];
      expect(photo[photoStore.userInput.selectedSortBy] <= nextPhoto[photoStore.userInput.selectedSortBy]).toBe(true);
    }
  });
};

const checkPhotographer = (photographer, functionKey) => {
  photoStore.userInput.selectedPhotographer = photographer;
  photoStore[functionKey]();
  expect(photoStore.photos.length > 0).toBe(true);
  photoStore.photos.forEach((photo) => {
    expect(photo.photographer).toEqual(photographer);
  });
};

const checkCurrency = () => {
  photoStore.photos.forEach((photo) => {
    expect(
      photo.priceInEuro * currencies[photoStore.userInput.selectedCurrency].comparedToEuro
    ).toEqual(photo.convertedPrice);
  });
};

test(`
Wanneer je photoStore.getTotalEuroPriceOfAllPhotos() uitvoerd krijg je de som van alle
prijzen van de foto's. Gebruik eerst de map array methode om een array aan te maken met alleen
de priceInEuro van de foto's als waardes: [58, 59, 62, 70, ...] 
Gebruik dan de reduce array methode om de som te berekenen.
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce
Bijvoorbeeld: photoStore.getTotalEuroPriceOfAllPhotos() => 702
`, () => {
  const fixedPrice = 50;
  photoStore.photos.forEach((photo) => photo.priceInEuro = fixedPrice);
  expect(photoStore.getTotalEuroPriceOfAllPhotos()).toEqual(fixedPrice * photoStore.photos.length);
});


test(`
Wanneer je photoStore.applyCurrencyChange() uitvoerd wordt een property convertedPrice
toegevoegd aan alle foto's. De waarde hiervan is gelijk aan de euro prijs maal de waarde
van de geselecteerde currency (this.userInput.selectedCurrency).
Gebruik voor deze oefening de forEach array methode
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
Bijvoorbeeld: nadat je photoStore.applyCurrencyChange() en this.userInput.selectedCurrency = 'DOLLAR'
dan moet photos het volgende resultaat geven:
[{ ..., priceInEuro: 58, convertedPrice: 64.38000000000001 }, { ..., priceInEuro: 59, convertedPrice: 65.49000000000001 }, ...]
`, () => {
  photoStore.userInput.selectedCurrency = 'DOLLAR';
  photoStore.applyCurrencyChange();
  checkCurrency();
});

test(`
Wanneer je photoStore.applySortBy() uitvoerd moeten alle foto's gesorteerd worden van laag naar hoog
afhankelijk van de waarde van selectedSortBy. Deze kan title of priceInEuro zijn.
Bijvoorbeeld als userInput.sortBy gelijk is aan priceInEuro dan moeten alle foto's gesorteerd zijn van 
goedkoopste naar duurste foto. Gebruik hiervoor de array sort methode.
Wanneer userInput.sortBy gelijk is aan title dan moeten alle foto's alfabetisch gesorteerd zijn op basis 
van de titel.
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/sort
`, () => {
  ['title', 'priceInEuro'].map(key => {
    photoStore.userInput.selectedSortBy = key;
    photoStore.applySortBy();
    checkSortBy();
  });
});


test(`
Wanneer je photoStore.applyPhotographerFilter() uitvoerd wordt this.photos gefiltered met alle foto's
waar fotograaf gelijk is aan de geselecteerde fotograaf in userInput.selectedPhotographer.
Bijvoorbeeld als photoStore.selectedPhotographer = 'Jorg Dickmann' 
en wanneer dan photoStore.applyPhotographerFilter() wordt uitgevoerd is photoStore.photo gelijk aan:
[{
  title: 'Brooklyn Colors',
  photographer: 'Jorg Dickmann',
  source: 'https://storage.googleapis.com/yk-cdn/photos/plp/jorg-dickmann/brooklyn-colors.jpg',
  priceInEuro: 64,
},
{
  title: 'The Great Wall I',
  photographer: 'Jorg Dickmann',
  source: 'https://storage.googleapis.com/yk-cdn/photos/plp/jorg-dickmann/brooklyn-colors.jpg',
  priceInEuro: 99,
}]

Wanneer userInput.selectedPhotographer gelijk is aan 'all', moeten alle foto's getoond worden
in photoStore.photos.
Gebruik voor deze oefening de filter array methode.
Tip: De .filter methode geeft een array terug en gaat de originele array niet aanpassen.
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter
`, () => {
  photoStore.userInput.selectedPhotographer = 'all';
  photoStore.applyPhotographerFilter();
  expect(photoStore.photos.length).toEqual(photos.length);
  checkPhotographer('Jorg Dickmann', 'applyPhotographerFilter');
});


/*
Extra oefening, zorg ervoor dat je de radio buttons dynamisch zijn, als bijvoorbeeld
een fotograaf naam wordt aangepast in de photos array, dan moet dit automatisch
aangepast worden in de radio buttons. Doe hetzelfde voor de currency en sort by.
Vergeet niet de logica eerst hier te schrijven en zo minimaal mogelijk code op 
de interface  
*/

/*
Extra oefening, zorg ervoor dat je ook de richting van de sort by kan bepalen
*/

/*
Extra oefening, zorg ervoor dat je op de titel van een foto kan zoeken
*/