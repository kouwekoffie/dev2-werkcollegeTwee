"use strict";
import { photoStore, currencies } from '../logic/index.js';


/*
De HTML om een foto product te tonen
alles in hoofdletters moet vervangen worden door dynamische inhoud. 
`
  <article>
    <img src="IMAGE_SOURCE" alt="ALT">
    <div class="article_content_wrapper">
      <div>
        <h3>TITLE</h3>
        <h4>PHOTOGRAPHER</h4>
      </div>
      <div class="price">PRICE</div>
    </div>
  </article>
`
*/

console.log(photoStore);